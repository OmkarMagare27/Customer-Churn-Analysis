CREATE DATABASE db_Churn
use db_Churn

select * from stg_Churn;